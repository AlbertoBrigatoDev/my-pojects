<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0" name="viewport">
    <title>Alberto Brigato invio messaggio</title>
    <meta content="Sito di presentazione di Alberto Brigato, web developer di Padova,messaggio inviato." name="description">
    <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">
      <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Satisfy" rel="stylesheet">
    
    <!-- Vendor CSS Files -->
    <link href="/assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="/assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
    <link href="/assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
    <link href="/assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">
       
    <!-- Template Main CSS File -->
    <link href="/assets/css/style.css" rel="stylesheet">

        <!-- =======================================================
    * Author: Alberto Brigato 
    * Author-mail: alberto.brigato00@gmail.com
    * License: No license.
    ======================================================== -->

</head>
<body>


<section id="hero">
    <div class="hero-container">
      <h1>Alberto Brigato</h1>
      <br>
      <br>
      <h2>Grazie per avermi contattato, risponderò quanto prima!</h2>

    </div>
  </section><!-- End Hero -->


<?php

// ricezione input del form

$name = $_POST['name'];

$email = $_POST['email'];

$subject = $_POST['subject'];

$clientMessage = $_POST['message'];

// headers

$headers  = 'MIME-Version: 1.0' . "\r\n";
$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";

// costruzione message

$message = '<html><body><h4>Messaggio da '. $name . '</h4>';

$message .= '<h5> Oggetto: ' . $subject . '</h5>';

$message .= '<p>' . $clientMessage . '</p>';

$message .= '</body></html>';

$to = 'alberto.brigato00@gmail.com';


// connessione a DB

$conn=mysqli_connect(localhost,"brigatoalberto","Bu4CNBr8VQdm","brigatoalberto");





// invio mail

mail($to, $subject, $message, $headers);




mysqli_close($conn);

?>

<!-- Vendor JS Files -->
<script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
<script src="assets/vendor/waypoints/noframework.waypoints.js"></script>
<!-- Template Main JS File -->
<script src="assets/js/main.js"></script>

</body>
</html>